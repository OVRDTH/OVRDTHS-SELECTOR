4.4.0

Instructions: 

UNINSTALL PREVIOUS VERSION BEFORE INSTALLING

Installation:

1. Extract contents of ZIP folder 
1. Run installation .EXE
2. Follow Instructions

Default install path is to documents now. 

HOW TO USE: 

The program is setup to mimic a traditional folder hierarchy. I'm sure you can figure it out, folder that would contain multiple loadouts or other folders SHOULD be bold lettered in order to differentiate between loadouts and organizational folders. 

Pre-loaded are some general folders:

OVRDTH'S LOADOUTS: Untraditional loadouts I have included 
TIERS: A folder containing Tiers 1-8. You can save specific tier loadouts here, but ultimately was included to be an example and can be deleted if you'd like.
YOUR LOADOUTS: Another example folder - Feel free to use it or delete it. Loadouts can still be saved to the main directory, similar to how other versions functioned.

To create a folder, hit the create folder button. In theory, the folder OR a saved loadout will go into the folder currently selected and outlined. If no folders are selected it will go into the main directory. 

MAKE SURE you don't have a LOADOUT selected when SAVING a NEW LOADOUT. I've tried my best to make this impossible but it can still happen. After loading a loadout, it should be deselected, but if you double click too quickly, it is highlighted again. Not a big deal if it happens.

SET KEYBIND: You can set a keybind in order to load the last selected loadout. This works when not tabbed into the program. 

SAVING LOADOUTS: In the main menu of Half Sword, select the loadout you'd like to use. Go into OVRDTH'S Selector and hit the SAVE LOADOUT button. It will be saved to whatever FOLDER is SELECTED. If there is folder selected, it will be put into the MAIN DIRECTORY. 

You can also drag and drop folders around as needed, to organized however you'd like inside the program. 

I couldn't get window resizing to work properly, if you have issues with it please contact me on discord @OVRDTH. I'm still trying to get it to function correctly. 

----------------------------------------------------------------------

Sub to me on Youtube for some rad Half Sword videos: https://www.youtube.com/@OVRDTH

---------------------------------------------------------------------------------------

Changelog 4.3.2:
Completely overhauled UI. 

Can now store loadouts in folders, and move loadouts around. 

Removed links to external websites( googles, nexus, youtube ) and prompt asking to if you'd like to check Nexus for an update ( This was causing flag from heuristic based malware checkers. )

Removed saved and load sensitivity buttons ( the game now saves settings on its own )

Fixed issue during installation where install path selection was removed and when selecting "no you don't want this location" installed to that location anyway ( lol )

Changed default install location away from Program Files to prevent the need to run as admin. Defaulting to documents

Removed most loadouts except a few to allow user to populate tool with their own.

Added my own custom loadouts


Changelog 3.2.1:
Added ability to save and load sensitivity
Added ability to "SET KEYBIND" which allows you to press the set keybind in order to activate the last double clicked loadout. You can use this keybind to select the last loadout used while tabbed into the game. So you don't have to alt tab. A sound will play if this is successful

Changelog 2.3.7:
Added functionality to save and name loadouts ( will save current selected halfsword loadout )
Added functionality to delete loadouts ( this will be gone forever ) 
Changed single click to double click when selecting loadouts
Changed dropdown menu to buttons in case the dropdown was missed
Changed buttons
Added version label 
Added ability to link directly to google drive for published versions

Changelog 1.2.7:
Created installer vs packaging into single .exe in hopes to stop AVS false flags

Changelog 1.2.6:
Updated Nexus Mods link to directly send to mod page vs to profile 

Changelog 1.2.5:
Removed update checker to reduce AV false positives
Replaced update checker with a reminder to check for updates with link to Nexus

Changelog 1.2.4:
Added update checker
Added changelog
Added Readme ability in program
Removed automatic update settings to help with AV false positive
Changed Header menu from "Help" to "Instructions"
Added mostly Tier 5 loadouts ( main class I play, initially this was just for myself )
